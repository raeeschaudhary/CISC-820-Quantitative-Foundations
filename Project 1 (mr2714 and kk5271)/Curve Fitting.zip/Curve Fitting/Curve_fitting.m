function Test_labels=Curve_fitting()
[Training_Data,Groud_Truth] = Load_data_Trainingset();
[Test_Data] = Load_data_Testset();
updates=Training_Data.^3;
features=[Training_Data updates];
Z_train=Z_formation(features);
updates_t=Test_Data.^3;
features_t=[Test_Data updates_t];
Z_test=Z_formation(features_t);
Weights=Linear_Regression(Z_train,Groud_Truth);
W=Weights.';
[~,length_Z]=size(Z_test);
Test_labels=zeros(length_Z,1);
for i=1:length_Z
   Test_labels(i)=(W*Z_test(:,i));
end
fileID = fopen('output.txt','w');
fprintf(fileID,'%5d\n',Test_labels);
fclose(fileID);
end
