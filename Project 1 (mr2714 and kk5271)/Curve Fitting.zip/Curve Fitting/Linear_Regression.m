function Weights=Linear_Regression(Z, Y)
M=Z*Z.';
S=Z*Y;
Weights=M\S;
end
