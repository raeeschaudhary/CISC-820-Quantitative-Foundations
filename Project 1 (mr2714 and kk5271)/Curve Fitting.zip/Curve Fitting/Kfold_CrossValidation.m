function [Train_Error, Test_Error]=Kfold_CrossValidation(X,Y, K)
Temp_X=X;
Temp_Y=Y;
fold_size=fix(length(X)/K);
fold_start=1;
fold_end=fold_size;
Train_Error=0;
Test_Error=0;

for i=1:K
    test_data=X(fold_start:fold_end,:);
    test_labels=Y(fold_start:fold_end,:);
    Temp_X(fold_start:fold_end,:)=[];
    Temp_Y(fold_start:fold_end,:)=[];
    train_data=Temp_X;
    train_labels=Temp_Y;
    
    fold_start=fold_start+fold_size;
    fold_end=fold_end+fold_size;


    Temp_X=X;
    Temp_Y=Y;

    if fold_end ==(length(X)-1)
        fold_end=length(X);
    end

     Z_train=Z_formation(train_data);
     Z_test=Z_formation(test_data);
     Weights=Linear_Regression(Z_train,train_labels);
     Train_Error = Train_Error+Mean_Squared_Error(Weights,Z_train,train_labels);
     Test_Error=Test_Error+Mean_Squared_Error(Weights,Z_test,test_labels);
end
Train_Error=Train_Error/K;
Test_Error=Test_Error/K;
end