function Reduced_Features_Set= MRMR (Features,Groud_Truth,size)
[ID,Score] = fscmrmr(Features,Groud_Truth);
bar(Score(ID))
xlabel('Predictor rank')
ylabel('Predictor importance score')
ID (1:size)
Reduced_Features_Set= Features(:,[4 5 6 7]);
end
