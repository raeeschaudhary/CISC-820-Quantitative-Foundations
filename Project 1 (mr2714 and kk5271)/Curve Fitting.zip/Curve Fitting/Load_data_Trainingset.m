function [Features,Groud_Truth] = Load_data_Trainingset()
traindata = importdata('traindata.txt');
Features = traindata(:,1:8);
Groud_Truth = traindata(:,9);
end