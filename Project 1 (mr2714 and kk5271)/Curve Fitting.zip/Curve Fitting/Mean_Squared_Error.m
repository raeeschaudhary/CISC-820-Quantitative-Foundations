function MSE = Mean_Squared_Error(Weights,Z,Y)
W=Weights.';
[~,length_Z]=size(Z);
Error=0;
for i=1:length_Z
    Error=Error+(W*Z(:,i)-Y(i,:))^2;
end
MSE=Error/length_Z;
end