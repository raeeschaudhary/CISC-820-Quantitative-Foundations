function Z=Z_formation(X)
Z=ones(length(X),1);
Z=[Z.';X.'];
end